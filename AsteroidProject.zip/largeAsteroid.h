#pragma once
#include "Asteroid.h"
class largeAsteroid :
	public Asteroid
{
public:
	largeAsteroid();
	~largeAsteroid();
};

