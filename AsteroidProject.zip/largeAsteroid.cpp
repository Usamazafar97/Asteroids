#include "largeAsteroid.h"



largeAsteroid::largeAsteroid()
{
}


largeAsteroid::~largeAsteroid()
{
}
