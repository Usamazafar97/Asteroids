#pragma once
#include "Asteroid.h"
class smallAsteroid :
	public Asteroid
{
public:
	smallAsteroid();
	~smallAsteroid();
};

