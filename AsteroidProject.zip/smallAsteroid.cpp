#include "smallAsteroid.h"



smallAsteroid::smallAsteroid()
{
}


smallAsteroid::~smallAsteroid()
{
}
